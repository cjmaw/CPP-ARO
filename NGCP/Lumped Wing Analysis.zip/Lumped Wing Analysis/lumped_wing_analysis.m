function lumped_wing_analysis (spanLoc,N,partOfPlane)
% Author: Cade Maw
% Date Created: 1/24/2025
% Last Updated: 1/30/2025

% xLoc is spanwise location of desired cross section for analysis
%   in FEET measured from the center of the fuselage
% N is the number of stringers on the upper and lower surface
%   (so 2N is the total number of stringers)
% partOfPLane MUST BE A STRING: 'Wing', 'Horz Tail', or 'Vert Tail'

FileFromXflr5 = 'MainWing_a=0.00_v=51.22fts.xlsx';

%%  ---- SETUP ----
%   ---- PART OF PLANE TO ANALYZE ----
w_semiSpan_ft = 4.411; % Wing
ht_semiSpan_ft = 1.076; % Horz Tail
vt_semiSpan_ft = 1.2; % Vert Tail

if partOfPlane == 'Wing'
    planePart = 'Wing';
    semiSpan_ft = w_semiSpan_ft;
    airfoilFile = 'NACA6415_airfoildata.xlsx';
elseif partOfPlane == 'Horz Tail'
    planePart = 'Horz Tail';
    semiSpan_ft = ht_semiSpan_ft;
    airfoilFile = 'NACA0010_airfoildata.xlsx';
elseif partOfPlane == 'Vert Tail'
    planePart = 'Vert Tail';
    semiSpan_ft = vt_semiSpan_ft;
    airfoilFile = 'NACA0010_airfoildata.xlsx';
else
    fprintf('Error in the part of plane you chose.')
end


%   ---- STRINGER DESIGN OPTIONS ----
stringerDiam = 3/8; % Stringer diameter in INCHES
Ftu = 348*144;      % Material Ult. Tensile Strength in PSF
Fcu = -300*144;     % Material Ult. Compressive Strength in PSF
Fsu = 700*144;      % Material Ult. Shear Strength in PSF


%   ---- READ XFLR5 DATA ----
read_xflr5(FileFromXflr5,w_semiSpan_ft,ht_semiSpan_ft,vt_semiSpan_ft);
xflr_fileName = 'RESULTS_read_xflr5.xlsx';
sheetName = planePart;

xflr5_data = readmatrix(xflr_fileName,'Sheet',sheetName);
span = xflr5_data(2:end,1);
chord = xflr5_data(2:end,2);
pitchingMoment = xflr5_data(2:end,6);
bendingMoment = xflr5_data(2:end,7);

%   ---- RUN AND READ SFBM DATA ----
xflr5_results_directory = strcat(pwd,'\',xflr_fileName);
cd 'Shear-Force-Bending-Moment'
run_SFBM(xflr5_results_directory,semiSpan_ft)
SFBM_fileName = 'Shear-Force-Bending-Moment\RESULTS_SFBM.xlsx';
SFBM_data = readmatrix(SFBM_fileName,'Range','A:C');
cd ..\
span_SFBM = SFBM_data(:,1);
shear_SFBM = SFBM_data(:,2);

%   ---- VALUES AT CHOSEN ANALYSIS LOCATION ALONG SPAN ---- 
    % From xflr5:
c = interp1(span,chord,spanLoc);
PM = interp1(span,pitchingMoment,spanLoc);
BM = interp1(span,bendingMoment,spanLoc);
    % From SFBM program:
idx = find(abs(span_SFBM - spanLoc) < 0.0001);
SF_SFBM = shear_SFBM(idx);


%% AIRFOIL AND STRINGERS
%   ---- IMPORT DATA FROM airfoilFile ----
airfoilData = readmatrix(airfoilFile);

%   ---- SPLIT UPPER AND LOWER AIRFOIL SURFACES ----
upperSurface = airfoilData(1:round(length(airfoilData(:,1))/2),:);
xU = flip(upperSurface(:,1)); % Goes LE to TE
yU = flip(upperSurface(:,2));

lowerSurface = airfoilData(round(length(airfoilData(:,1))/2):end,:);
xL = lowerSurface(:,1); % Goes LE to TE
yL = lowerSurface(:,2);


%   ---- INTERPOLATE FOR STRINGER LOCATIONS ----
xU_stringer = linspace(0,xU(end),N+2);     % N+2 is stringers at LE and TE
yU_stringer = interp1(xU,yU,xU_stringer,'spline');
    xU_stringer(1) = [];                   % Clear LE and TE stringers
    xU_stringer(end) = [];
    yU_stringer(1) = [];
    yU_stringer(end) = [];

xL_stringer = linspace(0,xL(end),N+2);     % N+2 is stringers at LE and TE
yL_stringer = interp1(xL,yL,xL_stringer,'spline');
    xL_stringer(1) = [];                   % Clear LE and TE stringers
    xL_stringer(end) = [];
    yL_stringer(1) = [];
    yL_stringer(end) = [];

x_str = c.*[flip(xL_stringer)';xU_stringer']; % Concatenate arrays
y_str = c.*[flip(yL_stringer)';yU_stringer']; % Goes CW from TE
    % Both multiplied by chord length since x and y were nondimensional


%   ---- STRINGER AREAS ----
area = (pi/4)*(stringerDiam/12)^2;  % Area of each stringer in feet^2
A_str = area*ones(2*N,1);           % Assumes all same area


%   ---- LUMPED SECTION PROPERTIES ----
Ay = A_str .* y_str;
Ax = A_str .* x_str;

    Atotal = sum(A_str);
    ybar = sum(Ay)/Atotal;
    xbar = sum(Ax)/Atotal;

Ixi = A_str .* (y_str - ybar).^2;
Iyi = A_str .* (x_str - xbar).^2;

    Ix = sum(Ixi);
    Iy = sum(Iyi); 


%   ---- COMPUTE AXIAL LOADS AND MARGINS OF SAFETY IN STRINGERS ----
% Beam Sign Convention (BSC) - Moment arrow points towards LE for +BSC
% Neglect chordwise bending

axial_stresses = BM .* (ybar-y_str) ./ Ix;
axial_forces = axial_stresses .* A_str;

axial_MS = zeros(2*N,1);
for i = 1:2*N
    if axial_stresses(i) >=0
        axial_MS(i,1) = Ftu/axial_stresses(i) - 1;
    else
        axial_MS(i,1) = Fcu/axial_stresses(i) - 1;
    end
end


%   ---- LUMPED BENDING RESULTS TABLE ----
No = 1:1:2*N;
No = No';
resultsTable = table(No,A_str,y_str,Ay,Ixi,axial_stresses,axial_forces,axial_MS)
writetable(resultsTable,'RESULTS_LumpedWing.xlsx','Sheet','Bending');


%   ---- Shear ----
% Assuming areas of stringers carry 

% Not done yet :)




%   ---- Plotting ----

    figure(10); hold on
    plot(c.*xU,c.*yU,'Color','b')
    plot(c.*xL,c.*yL,'Color','b')
    scatter(x_str,y_str,30,'k','filled')
    xlabel('Chordwise Length (ft)')
    ylabel('Thickness (ft)')
    xlim([-0.1 1.3])
    ylim([-0.35 0.45])
    hold off



   
    fprintf('\nLumped Section Properties:\n')
    fprintf('Total Area = %f feet^2\n',Atotal)
    fprintf('ybar = %f feet\n',ybar)
    fprintf('xbar = %f feet\n',xbar)
    fprintf('Ix = %f feet^4\n',Ix)
    fprintf('Iy = %f feet^4\n',Iy)




return