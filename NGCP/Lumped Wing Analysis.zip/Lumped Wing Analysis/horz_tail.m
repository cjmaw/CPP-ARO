function horz_tail
% Author: Cade Maw
% Date Created: 1/29/2025
% Last Updated: 1/29/2025

lumped_wing_analysis(3,5,'NACA0010_airfoildata.xlsx')









return