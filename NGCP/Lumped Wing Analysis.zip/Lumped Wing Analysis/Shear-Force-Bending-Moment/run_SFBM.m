function run_SFBM (xflr5_Results,semiSpan_ft)

lift = readmatrix(xflr5_Results,'Range','D39:R75');
xpos = readmatrix(xflr5_Results,'Range','A39:A75');

prob = SFBMProb('Wing',semiSpan_ft,0);
        prob.ForceUnit = "lb";
        prob.LengthUnit = "ft";

    for i = 1:length(lift)
        prob.AddPointLoad(lift(i),xpos(i));
    end


prob.Solve()

return