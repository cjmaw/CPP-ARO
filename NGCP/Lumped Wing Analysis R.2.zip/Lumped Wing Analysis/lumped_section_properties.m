function [xbar,ybar,Atotal,Ix,Iy] = lumped_section_properties (x_array,y_array,A_array)


Ay = A_array .* y_array;
Ax = A_array .* x_array;

    Atotal = sum(A_array);
    ybar = sum(Ay)/Atotal;
    xbar = sum(Ax)/Atotal;

Ixi = A_array .* (y_array - ybar).^2;
Iyi = A_array .* (x_array - xbar).^2;

    Ix = sum(Ixi);
    Iy = sum(Iyi); 



return