function lumped_wing_analysis (stringerProperties,sparProperties,sparLocs,planePart,semiSpan_ft,airfoilFile,FileFromXflr5,runOptions,AeroFactor,spanLoc,semiSpans)
% Author: Cade Maw
% Date Created: 1/24/2025
% Last Updated: 2/6/2025

% ALL UNITS ARE IN POUNDS FORCE AND FEET

%%  ---- UNPACK INPUTS ----
% Stringers
N = stringerProperties(1);
stringerDiam = stringerProperties(2);
Ftu_str = stringerProperties(3);
Fcu_str = stringerProperties(4);
Fsu_str = stringerProperties(5);

% Spars
numSpar = sparProperties(1);
sparDiam = sparProperties(2);
sparThick = sparProperties(3);
Ftu_spar = sparProperties(4);
Fcu_spar = sparProperties(5);
Fsu_spar = sparProperties(6);
x_spar = sparLocs(:,1);
y_spar = sparLocs(:,2);

% Semi-spans
w_semiSpan_ft = semiSpans(1);
ht_semiSpan_ft = semiSpans(2);
vt_semiSpan_ft = semiSpans(3);


%%  ---- READ XFLR5 AND RUN SFBM ----
%   ---- READ XFLR5 DATA ----
read_xflr5(FileFromXflr5,w_semiSpan_ft,ht_semiSpan_ft,vt_semiSpan_ft,...
                        AeroFactor);
xflr_fileName = 'RESULTS_read_xflr5.xlsx';
sheetName = planePart;
xflr5_data = readmatrix(xflr_fileName,'Sheet',sheetName);

% Unchanged by read_xflr5.m
span_xflr5 = xflr5_data(2:end,1);
chord_xflr5 = xflr5_data(2:end,2);

% Calculated by read_xflr5.m
pitchingMoment_xflr5 = xflr5_data(2:end,6);
bendingMoment_xflr5 = xflr5_data(2:end,7);


%   ---- RUN AND READ SFBM DATA ----
if runOptions == 1                                                       % Only runs SFBM if you tell it to
    xflr5_results_directory = strcat(pwd,'\',xflr_fileName);
    cd 'Shear-Force-Bending-Moment'
    run_SFBM(xflr5_results_directory,semiSpan_ft);
    SFBM_data = load('Shear-Force-Bending-Moment\RESULTS_SFBM.mat').MAT;
    cd ..\
    span_SFBM = SFBM_data(:,1);
    shear_SFBM = SFBM_data(:,2);
    moment_SFBM = SFBM_data(:,3);
end


%   ---- VALUES AT CHOSEN ANALYSIS LOCATION ALONG SPAN ---- 
    % From xflr5:
c = interp1(span_xflr5,chord_xflr5,spanLoc);                                % Chord length in FEET
PM = interp1(span_xflr5,pitchingMoment_xflr5,spanLoc);                      % Pitching moment in FT-LB
BM = interp1(span_xflr5,bendingMoment_xflr5,spanLoc);                       % Bending moment in FT-LB

    fprintf('\nBending Moment is %f ft-lb.\n\n',BM)

    % From SFBM program (if you run it):
if runOptions == 1
    idx = find(abs(span_SFBM - spanLoc) < 0.0001);
    SF_SFBM = shear_SFBM(idx);                                              % Shear force in LB
    BM_SFBM = moment_SFBM(idx);                                             % Not used, should be nearly the same as BM though

    fprintf('Shear Force is %f lb.\n\n',SF_SFBM)
end




%%  ---- SPAR AND STRINGER LUMPED BENDING ANALYSIS ----
%   ---- INTERPOLATE ALONG AIRFOIL FOR STRINGER LOCATIONS ----
[x_str,y_str] = airfoil_interp(c,N,airfoilFile);


%   ---- SPAR AND STRINGER AREAS ----
% Spars
area_spar = pi*sparDiam*sparThick;                                          % Area of each spar in FT^2
A_spar = area_spar*ones(numSpar,1);                                         % Assumes all same area

% Stringers
area_stringer = (pi/4)*(stringerDiam)^2;                                    % Area of each stringer in FT^2
A_str = area_stringer*ones(2*N,1);                                          % Assumes all same area

% Concatenate spar and stringer locations and areas
x_lumped = [x_str;x_spar];
y_lumped = [y_str;y_spar];
A_lumped = [A_str;A_spar];


%   ---- LUMPED SECTION PROPERTIES ----
[xbar,ybar,Atotal,Ix,Iy] = lumped_section_properties (x_lumped,y_lumped,...
                    A_lumped);


%   ---- COMPUTE AXIAL LOADS AND MARGINS OF SAFETY IN STRINGERS ----
% Beam Sign Convention (BSC) - Moment arrow points towards LE for +BSC
% Neglect chordwise bending
axial_stresses = BM .* (ybar-y_lumped) ./ Ix;                               % Moment*(ybar-yi)/Ix
axial_forces = axial_stresses .* A_lumped;                                  % Stress*area

% Pre-set array sizes to help for loops run faster
axial_MS_str = zeros(2*N,1);
axial_MS_spar = zeros(numSpar,1);

% Loop for MS in stringers
    for i = 1:2*N                   
        if axial_stresses(i) >=0
            axial_MS(i,1) = Ftu_str/axial_stresses(i) - 1;
        else
            axial_MS(i,1) = Fcu_str/axial_stresses(i) - 1;
        end
    end

% Loop for MS in spars
    for j = 2*N+1:2*N+numSpar       
        if axial_stresses(j) >=0
            axial_MS(j,1) = Ftu_spar/axial_stresses(j) - 1;
        else
            axial_MS(j,1) = Fcu_spar/axial_stresses(j) - 1;
        end
    end


%   ---- LUMPED BENDING RESULTS TO EXCEL ----
No = 1:1:2*N+numSpar;                                                       % List of numbers for lumped elements 1,2,3,4...
No = No'; 
bendingResultsTable = table(No,A_lumped,x_lumped,y_lumped,...
                    axial_stresses,axial_forces,axial_MS)
writetable(bendingResultsTable,'RESULTS_LumpedWing.xlsx','Sheet',...
                    'Bending');


%%  ---- SHEAR ANALYSIS ----
% if runOptions(1) == 1
% 
% % Not done yet :)
% 
% end


%%   ---- PLOTTING AND COMMAND WINDOW DISPLAY ----

% Plot spars and stringers with airfoil
figure(10); hold on
scatter(x_str,y_str,30,'k','filled')
scatter(x_spar,y_spar,60,'r','filled')
xlabel('Chordwise Length (ft)')
ylabel('Thickness (ft)')
xlim([-0.1*c 1.1*c])
ylim([-0.35*c 0.45*c])
title({'Locations of spars and stringers','Not to scale'})
hold off

% Print lumped section properties
fprintf('\nLumped Section Properties:\n')
fprintf('Total Area = %f feet^2\n',Atotal)
fprintf('ybar = %f feet\n',ybar)
fprintf('xbar = %f feet\n',xbar)
fprintf('Ix = %f feet^4\n',Ix)
fprintf('Iy = %f feet^4\n',Iy)


return