function read_xflr5 (fileName,w_semiSpan_ft,ht_semiSpan_ft,vt_semiSpan_ft,BrianFactor)
% Author: Cade Maw
% Date Created: 1/29/2025
% Last Updated: 1/31/2025

%% INSTRUCTIONS:
% fileName is the name of the xflr5 Excel file you'd like to read. It must
%   be called in a string.
% w-, ht-, and vt_semiSpan_ft are the half-spans (middle fuselage to
%   lifting surface tip) of the wing (w), horizontal tail (ht), and
%   vertical tail (vt), all in FEET.
% BrianFactor is factor from aerodynamics team to scale up loads to a
%   different velocity.

% This program has no function output because it writes directly to an
%   Excel file. Change name of export file below, if desired.

% You may need to verify that read_xflr5.m is looking at the correct Excel
%   ranges for your xflr5 file.

%% CADE NOTE TO SELF: VERIFY VT TIPS SINCE HALF WING
%%  ---- SETUP ----
    % Middle of fuselage to tips of wing, horz tail, vert tail in FEET
Vinf_fts = readmatrix(fileName,'Range','B5:B5');
    % Verify that value in B2 is in ft/s
q = 0.0024*0.5*Vinf_fts^2;
    % Imperial units
    
%   ---- EXPORT OPTIONS ----
exportFile = 'RESULTS_read_xflr5.xlsx';


%%  ---- WING ----
% Information directly from xflr5
w_yspan_meters = readmatrix(fileName,'Range','A22:A95');
w_chord_meters = readmatrix(fileName,'Range','B22:B95');
w_CL           = readmatrix(fileName,'Range','D22:D95');
w_CD_profile   = readmatrix(fileName,'Range','E22:E95');
w_CD_induced   = readmatrix(fileName,'Range','F22:F95');
w_CM_qrtchord  = readmatrix(fileName,'Range','H22:H95');
w_BM_Nm        = readmatrix(fileName,'Range','L22:L95');

% Convert to imperial units (ft and lbs)
w_span = 3.28084.*w_yspan_meters;
    w_span2 = [-w_semiSpan_ft;w_span;w_semiSpan_ft];
    % w_span2 adds span data points at wing tips to compute section area
w_chord = 3.28084.*w_chord_meters;
w_chord_avg = (min(w_chord)+max(w_chord))/2;
w_BM = BrianFactor*0.7376.*w_BM_Nm;

% Pre-set array sizes to help for loop run faster
w_sectArea = zeros(length(w_span),1);
w_sectLift = zeros(length(w_span),1);
w_sectDrag = zeros(length(w_span),1);
w_sectPM = zeros(length(w_span),1);
for i = 1:length(w_span)
    w_sectArea(i) = abs(w_span2(i) - w_span2(i+2)) * w_chord(i)/2;
    w_sectLift(i) = BrianFactor*w_CL(i)*q*w_sectArea(i);
    w_sectDrag(i) = BrianFactor*(w_CD_profile(i)+...
                            w_CD_induced(i))*q*w_sectArea(i);
    w_sectPM(i) = BrianFactor*w_CM_qrtchord(i)*q*w_chord_avg*w_sectArea(i);
end


T1 = table(w_span,w_chord,w_sectArea,w_sectLift,w_sectDrag,w_sectPM,w_BM);


%%  ---- HORZ TAIL ----
% Information directly from xflr5
ht_yspan_meters = readmatrix(fileName,'Range','A100:A141');
ht_chord_meters = readmatrix(fileName,'Range','B100:B141');
ht_CL = readmatrix(fileName,'Range','D100:D141');
ht_CD_profile = readmatrix(fileName,'Range','E100:E141');
ht_CD_induced = readmatrix(fileName,'Range','F100:F141');
ht_CM_qrtchord = readmatrix(fileName,'Range','H100:H141');
ht_BM_Nm = readmatrix(fileName,'Range','L100:L141');

% Convert to imperial units (ft and lbs)
ht_span = 3.28084.*ht_yspan_meters;
    ht_span2 = [-ht_semiSpan_ft;ht_span;ht_semiSpan_ft];
    % ht_span2 adds span data points at tips to compute section area
ht_chord = 3.28084.*ht_chord_meters;
ht_chord_avg = (min(ht_chord)+max(ht_chord))/2;
ht_BM = BrianFactor*0.7376.*ht_BM_Nm;

% Pre-set array sizes to help for loop run faster
ht_sectArea = zeros(length(ht_span),1);
ht_sectLift = zeros(length(ht_span),1);
ht_sectDrag = zeros(length(ht_span),1);
ht_sectPM = zeros(length(ht_span),1);
for i = 1:length(ht_span)
    ht_sectArea(i) = abs(ht_span2(i) - ht_span2(i+2)) * ht_chord(i)/2;
    ht_sectLift(i) = BrianFactor*ht_CL(i)*q*ht_sectArea(i);
    ht_sectDrag(i) = BrianFactor*(ht_CD_profile(i)+...
                            ht_CD_induced(i))*q*ht_sectArea(i);
    ht_sectPM(i) = BrianFactor*ht_CM_qrtchord(i)*q*...
                            ht_chord_avg*ht_sectArea(i);
end

T2 = table(ht_span,ht_chord,ht_sectArea,ht_sectLift,...
                            ht_sectDrag,ht_sectPM,ht_BM);


%%  ---- VERT TAIL ----
% Information directly from xflr5
vt_yspan_meters = readmatrix(fileName,'Range','A146:A158');
vt_chord_meters = readmatrix(fileName,'Range','B146:B158');
vt_CL = readmatrix(fileName,'Range','D146:D158');
vt_CD_profile = readmatrix(fileName,'Range','E146:E158');
vt_CD_induced = readmatrix(fileName,'Range','F146:F158');
vt_CM_qrtchord = readmatrix(fileName,'Range','H146:H158');
vt_BM_Nm = readmatrix(fileName,'Range','L146:L158');

% Convert to imperial units (ft and lbs)
vt_span = 3.28084.*vt_yspan_meters;
    vt_span2 = [-vt_semiSpan_ft;vt_span;vt_semiSpan_ft];
    % vt_span2 adds span data points at tips to compute section area
vt_chord = 3.28084.*vt_chord_meters;
vt_chord_avg = (min(vt_chord)+max(vt_chord))/2;
vt_BM = BrianFactor*0.7376.*vt_BM_Nm;

% Pre-set array sizes to help for loop run faster
vt_sectArea = zeros(length(vt_span),1);
vt_sectLift = zeros(length(vt_span),1);
vt_sectDrag = zeros(length(vt_span),1);
vt_sectPM = zeros(length(vt_span),1);
for i = 1:length(vt_span)
    vt_sectArea(i) = abs(vt_span2(i) - vt_span2(i+2)) * vt_chord(i)/2;
    vt_sectLift(i) = BrianFactor*vt_CL(i)*q*vt_sectArea(i);
    vt_sectDrag(i) = BrianFactor*(vt_CD_profile(i)+...
                            vt_CD_induced(i))*q*vt_sectArea(i);
    vt_sectPM(i) = BrianFactor*vt_CM_qrtchord(i)*q*...
                            vt_chord_avg*vt_sectArea(i);
end

T3 = table(vt_span,vt_chord,vt_sectArea,vt_sectLift,...
                            vt_sectDrag,vt_sectPM,vt_BM);


%%   ---- WRITE TO EXCEL ----
recycle on
delete(exportFile);
writetable(T1,exportFile,'Sheet','Wing');
writetable(T2,exportFile,'Sheet','Horz Tail');
writetable(T3,exportFile,'Sheet','Vert Tail');

return