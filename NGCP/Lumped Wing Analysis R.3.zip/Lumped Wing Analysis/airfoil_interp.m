function [x_str,y_str] = airfoil_interp(c,N,airfoilFile)
% This script will compute the x and y locations of stringers
%   (in the same units as the chord length, c) by interpolating
%   nondimensional airfoil coordinates from Excel.
% N is the desired number of stringers.

% Author: Cade Maw
% Date created: 1/31/25
% Last Updated: 1/31/25


%   ---- IMPORT DATA FROM airfoilFile ----
airfoilData = readmatrix(airfoilFile);

%   ---- SPLIT UPPER AND LOWER AIRFOIL SURFACES ----
upperSurface = airfoilData(1:round(length(airfoilData(:,1))/2),:);
xU = flip(upperSurface(:,1)); % Goes LE to TE
yU = flip(upperSurface(:,2));

lowerSurface = airfoilData(round(length(airfoilData(:,1))/2):end,:);
xL = lowerSurface(:,1); % Goes LE to TE
yL = lowerSurface(:,2);

%   ---- INTERPOLATE FOR STRINGER LOCATIONS ----
xU_stringer = linspace(0,xU(end),N+2);     % N+2 is stringers at LE and TE
yU_stringer = interp1(xU,yU,xU_stringer,'spline');
    xU_stringer(1) = [];                   % Clear LE and TE stringers
    xU_stringer(end) = [];
    yU_stringer(1) = [];
    yU_stringer(end) = [];

xL_stringer = linspace(0,xL(end),N+2);     % N+2 is stringers at LE and TE
yL_stringer = interp1(xL,yL,xL_stringer,'spline');
    xL_stringer(1) = [];                   % Clear LE and TE stringers
    xL_stringer(end) = [];
    yL_stringer(1) = [];
    yL_stringer(end) = [];

x_str = c.*[flip(xL_stringer)';xU_stringer']; % Concatenate arrays
y_str = c.*[flip(yL_stringer)';yU_stringer']; % Goes CW from TE
    % Both multiplied by chord length since x and y were nondimensional



%   ---- PLOT AIRFOIL ----
figure(10);
hold on
plot(c.*xU,c.*yU,'Color','b');
plot(c.*xL,c.*yL,'Color','b');
hold off

return